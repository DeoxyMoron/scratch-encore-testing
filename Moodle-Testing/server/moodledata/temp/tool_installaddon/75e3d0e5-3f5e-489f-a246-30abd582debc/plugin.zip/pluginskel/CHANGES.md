## 1.0.0 ##

* Added support to generate plugins requiring Moodle 3.3 and 3.2.
* Added support for setting default values of some recipe file form fields
* Fixed the risk of having the generated ZIP file corrupted with debugging data
* Fixed some formal coding style violations


## 0.9.0 ##

* Initial version submitted to the Moodle plugins directory as a result of
  GSOC 2016
